package com.qa.orangehrm.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.orangehrm.base.TestBase;
import com.qa.orangehrm.pages.AccountSummaryPage;
import com.qa.orangehrm.pages.LoginPage;


public class LoginPageTestCase extends TestBase {


	LoginPage loginpage;
	AccountSummaryPage accountsummarypage;

	public LoginPageTestCase() {
		super();
	}

	@BeforeMethod
	public void setup() {

		initialization();

		loginpage = new LoginPage();
		accountsummarypage = new AccountSummaryPage();

	}

	@AfterMethod
	public void quit() {
		driver.close();
		driver.quit();

	}

	@Test
	public void navigateToAccountSummaryPageTest()  {
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.assertAccountSummaryPageTitle();

	}


}
