package com.qa.orangehrm.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.orangehrm.base.TestBase;
import com.qa.orangehrm.pages.AccountSummaryPage;
import com.qa.orangehrm.pages.LoginPage;

public class AccountSummaryPageTestCases extends TestBase {

	LoginPage loginpage;
	AccountSummaryPage accountsummarypage;

	public AccountSummaryPageTestCases() {

		super();
	}

	@BeforeMethod
	public void setup() {

		initialization();
		accountsummarypage = new AccountSummaryPage();

	}


	@AfterMethod
	public void quit() {
		driver.close();
		driver.quit();

	}

	@Test
	public void validateAccountSummaryPageTitle() {
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.assertAccountSummaryPageTitle();

	}

}
