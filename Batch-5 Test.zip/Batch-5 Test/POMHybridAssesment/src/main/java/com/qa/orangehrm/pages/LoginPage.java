package com.qa.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.orangehrm.base.TestBase;

public class LoginPage extends TestBase{

	@FindBy(id="txtUsername")
	WebElement UserLogin;

	@FindBy(id="txtPassword")
	WebElement UserPassword;

	@FindBy(name="btnLogin")
	WebElement SubmitButton;

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertLoginPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}

	
	public AccountSummaryPage navigateToAccountSummaryPage() {
		UserLogin.sendKeys("admin");
		UserPassword.sendKeys("admin123");
		SubmitButton.click();
		System.out.println("Navigated to Account summary page");
		return new AccountSummaryPage();

	}
	
	
}
