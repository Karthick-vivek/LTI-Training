package com.qa.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.qa.orangehrm.base.TestBase;

public class AccountSummaryPage extends TestBase {

	@FindBy(id="menu_recruitment_viewRecruitmentModule")
	WebElement recruitmentMenu;

	@FindBy(id="menu_recruitment_viewCandidates")
	WebElement candidateMenu;

	@FindBy(id = "btnAdd")
	WebElement addButton;

	@FindBy(id="addCandidate_firstName")
	WebElement firstName;

	@FindBy(id="addCandidate_lastName")
	WebElement lastName;

	@FindBy(id="addCandidate_email")
	WebElement emailID;

	@FindBy(id="addCandidate_contactNo")
	WebElement contactNo;

	@FindBy(id="addCandidate_vacancy")
	WebElement jobVacancy;

	@FindBy(id="addCandidate_keyWords")
	WebElement keyWords;

	@FindBy(id="btnSave")
	WebElement saveButton;	

	@FindBy(id="btnBack")
	WebElement backButton;

	@FindBy(id="btnSrch")
	WebElement searchButton;

	@FindBy(id="candidateSearch_candidateName")
	WebElement searchCandidate;




	public AccountSummaryPage() {
		PageFactory.initElements(driver, this);

	}

	public void assertAccountSummaryPageTitle() {

		assertEquals(driver.getTitle(), "OrangeHRM");
	}


	public void addCandidateDetails() {



		Actions act = new Actions(driver);
		act.moveToElement(recruitmentMenu).moveToElement(candidateMenu).click().build().perform();

		//Name
		firstName.sendKeys("Karthick");
		lastName.sendKeys("vivek");
		//MailID
		emailID.sendKeys("test@gmail.com");
		//Contact No
		contactNo.sendKeys("123456789");

		//Job title
		Select select = new Select(jobVacancy);
		select.selectByVisibleText("Associate IT Manager");

		//Keywords
		keyWords.sendKeys("People Managment");

		saveButton.click();

		System.out.println("Candidate necessary details have been entered");

		backButton.click();

		searchButton.click();


	}


	public void validateCandidate() {

		searchCandidate.sendKeys("Karthick vivek");
		searchButton.click();

		System.out.println("Validation is successful");


	}


}
