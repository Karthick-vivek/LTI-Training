package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class LoginPage extends TestBase {

	@FindBy(id ="user_login")
	WebElement username;

	@FindBy(name="user_password")
	WebElement password;

	@FindBy(name="user_remember_me")
	WebElement checkbox;

	@FindBy(id="credentials")
	WebElement questionmark;

	@FindBy(name="submit")
	WebElement signin;

	@FindBy(id="details-button")
	WebElement detailbutton;

	@FindBy(id="proceed-link")
	WebElement proceedlink;


	public LoginPage() {

		PageFactory.initElements(driver, this);

	}

	public void assertHomePageTitle() {

		assertEquals(driver.getTitle(), "Zero - Log in", "Mismatch found");

	}

	public AccountSummaryPage loginPage() {

		username.sendKeys(prop.getProperty("username"));
		username.sendKeys(prop.getProperty("password"));
		signin.click();
		detailbutton.click();
		proceedlink.click();
		return new AccountSummaryPage();
	}
}
