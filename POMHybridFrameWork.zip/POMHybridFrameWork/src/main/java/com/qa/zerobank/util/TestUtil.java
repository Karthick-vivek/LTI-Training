package com.qa.zerobank.util;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.qa.zerobank.base.TestBase;

public class TestUtil extends TestBase{

	static JavascriptExecutor js;
	Connection con;

	public static void takeScreenshot(String pageName) {

		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

		String homeDir = System.getProperty("user.dir");

		try {
			FileUtils.copyFile(srcFile,  new File (homeDir +"/screenshots+/" + pageName + System.currentTimeMillis()+".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void executeExeFile(String fileName) {

		try {
			Runtime.getRuntime().exec(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void  executeJavaScript(String jsQuery) {
		js=(JavascriptExecutor) driver;
		js.executeScript(jsQuery);

	}

	//open db connection
	public Connection createDBConnection() throws ClassNotFoundException, SQLException{

		//load driver jar class
		Class.forName("com.mysql.jdbc.Driver");   
		System.out.println("MySQL connection Driver loaded");

		//Create connection
		con = DriverManager.getConnection(
				"jdbc:mysql://" + prop.getProperty("dbhost") + ":" + prop.getProperty("port") + "/"
						+ prop.getProperty("dbname"), prop.getProperty("dbuser"), prop.getProperty("dbpassword")
				);


		//con = DriverManager.getConnection("jdbc:mysql://dbhost:port/dbname", dbuser, dbpassword);

		System.out.println("Connected to MySQL DB");

		return con;
	}

	//process

	public ResultSet executeDBQuery(Connection con, String query) throws SQLException{           
		//create statement
		Statement smt = con.createStatement();           
		//execute query
		ResultSet rs = smt.executeQuery(query);
	//	System.out.println(rs);
		return rs;   
	}
	//close db connection

	public void closeConnection(Connection con) throws SQLException {
		con.close();

	}
}



