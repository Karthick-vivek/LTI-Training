package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.qa.zerobank.base.TestBase;

public class HomePage extends TestBase{

	@FindBy(id ="signin_button")
	WebElement signInButton;

	@FindBy(name="searchTerm")
	WebElement searchBox;

	@FindBy(linkText="Zero Bank")
	WebElement pageTitle;


	@FindBy(id="onlineBankingMenu")
	WebElement onlineBanking;

	@FindBy(id="feedback")
	WebElement feedBack;

	@FindBy(id="online-banking")
	WebElement onlineBankingButton;

	@FindBy(id="account_activity_link")
	WebElement accountActivity;

	@FindBy(id="transfer_funds_link")
	WebElement transferFund;

	@FindBy(id="money_map_link")
	WebElement moneyMap;

	@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][1]")
	WebElement privacyLink1;

	@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][2]")
	WebElement privacyLink2;



	public HomePage() {
		PageFactory.initElements(driver, this);

	}

	public void assertHomePageTitle() {

		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Mismatch found");

	}

	public boolean brandName() {

		return pageTitle.isDisplayed();
	}
	
	public LoginPage clickOnSignButton() {
		signInButton.click();
		return new LoginPage();
		
	}
}




