package restassueredassignments;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class GetRequestSingleUserNotFound {
	
	@Test
	public void testGetRequestSingleUserNotFound() {
		
		baseURI = "https://reqres.in/api/";

		given()
		.get("/users/23")
		.then()
		.statusCode(404)
		.log().body();
		
	}

}
