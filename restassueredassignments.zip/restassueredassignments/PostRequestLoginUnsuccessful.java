package restassueredassignments;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;

public class PostRequestLoginUnsuccessful {

@Test
	public void testPostRequest() {

		baseURI = "https://reqres.in/api";

		JSONObject json = new JSONObject();
		json.put("email", "peter@klaven");

		System.out.println(json.toJSONString());


		given()
		.body(json.toJSONString())
		.when()
		.post("/register")
		.then()
		.statusCode(400)
		
		.log().body();
	}


}


