package restassueredassignments;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;
import static org.hamcrest.Matchers.*;


public class PostRequestLoginUnsuccessful {

@Test
	public void testPostRequestLoginUnsuccessful() {

		baseURI = "https://reqres.in/api";

		JSONObject json = new JSONObject();
		json.put("email", "peter@klaven");

		System.out.println(json.toJSONString());


		given()
		.body(json.toJSONString())
		
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		
		.when()
		.post("/register")
		.then()
		.statusCode(400)
		.body("error", equalTo("Missing password"))
		.log().body();
	}


}


