package restassueredassignments;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

import org.testng.annotations.Test;

public class GetRequestSingle {
	
	@Test
	public void testGetRequest() {

		baseURI = "https://reqres.in/api/";

		given()
		.get("/unknown/2")
		.then()
		.statusCode(200)
		
		.body("data.id", equalTo(2))
		.body("data.name", equalTo("fuchsia rose"))
		.body("data.year", equalTo(2001))
		.body("data.color", equalTo("#C74375"))
		.body("data.pantone_value", equalTo("17-2031"))
		
		.log().headers()
		.log().status()
		.log().ifStatusCodeIsEqualTo(200)
		.log().body();


	}


}
