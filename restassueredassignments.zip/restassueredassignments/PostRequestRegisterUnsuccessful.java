package restassueredassignments;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;


public class PostRequestRegisterUnsuccessful {

	@Test
	public void testPostRequest() {
		baseURI = "https://reqres.in/api";

		JSONObject json = new JSONObject();
		json.put("email", "sydney@fife");

		System.out.println(json.toJSONString());


		given()
		.body(json.toJSONString())
		.when()
		.post("/register")
		.then()
		.statusCode(400)
		
		.log().body();
	}


}
