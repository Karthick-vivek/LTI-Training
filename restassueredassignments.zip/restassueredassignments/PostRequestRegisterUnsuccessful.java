package restassueredassignments;

import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;


public class PostRequestRegisterUnsuccessful {

	@Test
	public void testPostRequestRegisterUnsuccessful() {
		baseURI = "https://reqres.in/api";

		JSONObject json = new JSONObject();
		json.put("email", "sydney@fife");

		System.out.println(json.toJSONString());


		given()
		.body(json.toJSONString())
		
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		
		.when()
		.post("/register")
		.then()
		.statusCode(400)
		.body("error", equalTo("Missing password"))
		.log().body();
	}


}
