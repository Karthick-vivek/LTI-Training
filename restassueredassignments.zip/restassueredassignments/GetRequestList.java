package restassueredassignments;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;

public class GetRequestList {

	@Test
	public void testGetRequest() {

		baseURI = "https://reqres.in/api/";

		given()
		.get("/unknown")
		.then()
		.statusCode(200)
		
		.body("data[0].id", equalTo(1))
		.body("data[1].id", equalTo(2))
		.body("data[2].id", equalTo(3))
		.body("data[3].id", equalTo(4))
		.body("data[4].id", equalTo(5))
		.body("data[5].id", equalTo(6))
		
		.body("data[0].name", equalTo("cerulean"))
		.body("data[1].name", equalTo("fuchsia rose"))
		.body("data[2].name", equalTo("true red"))
		.body("data[3].name", equalTo("aqua sky"))
		.body("data[4].name", equalTo("tigerlily"))
		.body("data[5].name", equalTo("blue turquoise"))
		
		.body("data.name", hasItems("cerulean", "fuchsia rose", "true red", "aqua sky", "tigerlily", "blue turquoise"))
		
		.body("page", equalTo(1))
		.body("per_page", equalTo(6))
		.body("total", equalTo(12))
		.body("total_pages", equalTo(2))
		
		.log().headers()
		.log().status()
		.log().body();


	}

}
