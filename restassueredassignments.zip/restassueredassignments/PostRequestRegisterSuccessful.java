package restassueredassignments;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class PostRequestRegisterSuccessful {


	@Test
	public void testPostRequestRegisterSuccessful() {
		baseURI = "https://reqres.in/api";

		JSONObject json = new JSONObject();
		json.put("email", "eve.holt@reqres.in");
		json.put("password", "pistol");


		System.out.println(json.toJSONString());


		given()
		.body(json.toJSONString())
		
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		
		.when()
		.post("/register")
		.then()
		.statusCode(200)
		
		.log().ifStatusCodeIsEqualTo(200)
		.log().body();
	}

}
