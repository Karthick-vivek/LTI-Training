package restassueredassignments;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class GetRequestSingleNotFound {
	
	@Test
	public void testGetRequest() {
		
		baseURI = "https://reqres.in/api/";

		given()
		.get("/unknown/23")
		.then()
		.statusCode(404)
		.log().body();
		
	}


}
