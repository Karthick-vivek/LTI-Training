package assignmentWeek2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NegativeTestCase {


	public WebDriver driver ;

	@BeforeTest
	public void setupTest() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDriver\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("http://zero.webappsecurity.com/");

		System.out.println("****Launched the browser****");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority = 1, groups = {"Regression"})
	public void loginTest() {

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password123");

		driver.findElement(By.name("submit")).click();

		String loginAndorPassword = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();

		Assert.assertEquals(loginAndorPassword, "Login and/or password are wrong.");

	}


	@Test(priority = 2, groups = {"Regression"})
	public void userName() {

		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");


		driver.findElement(By.id("btnLogin")).click();

		String usernameCannotBe = driver.findElement(By.xpath("//span[text()='Username cannot be empty']")).getText();

		Assert.assertEquals(usernameCannotBe, "Username cannot be empty");
	}



	@Test(priority = 4, groups = {"Regression"})
	public void emptyPassword() {

		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");

		driver.findElement(By.id("txtUsername")).sendKeys("Admin");

		driver.findElement(By.id("btnLogin")).click();

		String passwordnameCannotBe = driver.findElement(By.xpath("//span[text()='Password cannot be empty']")).getText();

		Assert.assertEquals(passwordnameCannotBe, "Password cannot be empty");
	}

	@Test(priority = 3, groups = {"Regression"})
	public void invalidCred() {

		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin123");

		driver.findElement(By.id("txtPassword")).sendKeys("admin123");

		driver.findElement(By.id("btnLogin")).click();

		String invalidCred = driver.findElement(By.xpath("//span[text()='Invalid credentials']")).getText();

		Assert.assertEquals(invalidCred, "Invalid credentials");
	}


	@AfterTest
	public void tearDown() {
		driver.close();

		driver.quit();

	}

}



