package assignmentWeek2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NegativeTestCase {


	public static WebDriver driver ;
	public static WebDriverWait ExplicitWait;

	@BeforeTest
	public void setupTest() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDriver\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("http://zero.webappsecurity.com/");

		System.out.println("****Launched the browser****");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority = 1, groups = {"Regression"}, alwaysRun = true)
	public void loginPage() {

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password123");

		driver.findElement(By.name("submit")).click();

		String invalidCredentials = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();

		Assert.assertEquals(invalidCredentials, "Login and/or password are wrong.!", "String mismatch found-1");

	}




	@Test(priority = 2, groups = {"Regression"}, alwaysRun = true)
	public void homePage() {

		driver.navigate().to("http://zero.webappsecurity.com/");

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.id("details-button")).click();

		driver.findElement(By.xpath("//a[@id='proceed-link']")).click();

		String pageTitle = driver.getTitle();

		Assert.assertEquals(pageTitle, "Zero - Account Summary!", "String mismatch found-2");


	}



	@Test(priority = 3, groups = {"Regression"}, alwaysRun = true)
	public void transferFund() {

		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();

		driver.findElement(By.cssSelector("a#logout_link")).click();

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.linkText("Transfer Funds")).click();

		String transferMoney = driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")).getText();

		Assert.assertEquals(transferMoney, "Transfer Money & Make Payments!", "String mismatch found-3");

	}

	@Test(priority = 4, groups = {"Regression"}, alwaysRun = true)
	public void payBills() {

		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();

		driver.findElement(By.cssSelector("a#logout_link")).click();

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.linkText("Pay Bills")).click();

		String payBills = driver.findElement(By.xpath("//h2[text()='Make payments to your saved payees']")).getText();

		Assert.assertEquals(payBills, "Make payments to your saved payees!", "String mismatch found-4");




	}

	@Test(priority = 5, groups = {"Regression"}, alwaysRun = true)
	public static void transferFunds2() {

		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();

		driver.findElement(By.cssSelector("a#logout_link")).click();

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.linkText("Transfer Funds")).click();
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(
				driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")),
				"Transfer Money & Make Payments"));

		WebElement fromAccountId = driver.findElement(By.name("fromAccountId"));
		Select select = new Select(fromAccountId);
		select.selectByValue("2");
		WebElement To = driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select(To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");
		driver.findElement(By.id("tf_amount")).sendKeys("");

		driver.findElement(By.id("tf_amount")).sendKeys("100");		

		driver.findElement(By.xpath("//button[text()='Continue']")).click();

		Assert.assertEquals(driver.findElement(By.tagName("h2")).getText(), "Transfer Money & Make Payments - Verify!", "String mismatch found-5");

		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();

		driver.findElement(By.cssSelector("a#logout_link")).click();


	}

	@AfterTest
	public void tearDown() {
		driver.close();

		driver.quit();

	}

}



