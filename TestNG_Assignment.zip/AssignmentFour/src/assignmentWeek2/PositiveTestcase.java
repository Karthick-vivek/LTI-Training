package assignmentWeek2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PositiveTestcase {


	public WebDriver driver ;

	@BeforeGroups
	public void setupTest() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDriver\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("http://zero.webappsecurity.com/");

		System.out.println("****Launched the browser****");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test (priority = 1, groups = {"Smoke"})
	public void loginTest() {

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		System.out.println("Signed in");

		driver.findElement(By.id("details-button")).click();

		driver.findElement(By.xpath("//a[@id='proceed-link']")).click();

		driver.findElement(By.linkText("Pay Bills")).click();

		WebDriverWait eWait = new WebDriverWait(driver, 5);

		eWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Make payments to your saved payees']")), "Make payments to your saved payees"));

		System.out.println("EWAIT Worked 1");
		driver.findElement(By.linkText("Purchase Foreign Currency")).click();

		eWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Purchase foreign currency cash']")), "Purchase foreign currency cash"));
		System.out.println("EWAIT Worked 2");


		driver.findElement(By.id("purchase_cash")).click();

		Alert alert = driver.switchTo().alert();

		String text = alert.getText();
		System.out.println(text);

		Assert.assertEquals(text,"Please, ensure that you have filled all the required fields with valid values.","Alert text is not matching");

		alert.accept();

		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();

		eWait.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector("a#logout_link"))));

		driver.findElement(By.cssSelector("a#logout_link")).click();

		System.out.println("Clicked Logged out with EWAIT");


		System.out.println("***Run Successful***");
	}


	@Test(priority = 2, groups = {"Smoke"})
	public void fundTransfer() {

		driver.findElement(By.id("signin_button")).click();

		System.out.println("Clicked sigin button");

		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@name, 'user_password')]")).sendKeys("password");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.linkText("Transfer Funds")).click();

		WebElement fromAccountId = driver.findElement(By.name("fromAccountId")); 

		Select select = new Select(fromAccountId);

		select.selectByValue("2");

		WebElement To=driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select (To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");

		driver.findElement(By.id("tf_amount")).sendKeys("1000");

		driver.findElement(By.id("tf_description")).sendKeys("test");

		driver.findElement(By.id("btn_submit")).click();

	}

	@AfterGroups
	public void tearDown() {
		driver.close();

		driver.quit();

	}

}
