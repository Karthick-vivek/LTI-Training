package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class AccountSummaryPage extends TestBase {
	
	@FindBy(xpath = "(//a[@class='dropdown-toggle'])[2]")
	WebElement signoutdropdown;
	
	@FindBy(id = "logout_link")
	WebElement logout;
	

	public AccountSummaryPage() {
		PageFactory.initElements(driver, this);

	}

	public void assertAccountSummaryPageTitle() {

		assertEquals(driver.getTitle(), "Zero - Account Summary");
	}
	
	public HomePage signOut() {
		
		signoutdropdown.click();
		logout.click();
		return new HomePage();
	}
}
