package com.qa.zerobank.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LoginPage;


public class LoginPageTestCase extends TestBase {

	HomePage homepage;
	LoginPage loginpage;
	AccountSummaryPage accountsummarypage;

	public LoginPageTestCase() {
		super();
	}

	@BeforeMethod
	public void setup() {

		initialization();
		homepage = new HomePage();
		loginpage = new LoginPage();
		accountsummarypage = new AccountSummaryPage();

	}

	@AfterMethod
	public void quit() {
		driver.close();
		driver.quit();

	}

	@Test
	public void validateLogInPageFunctionality() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();


	}

	@Test
	public void enterInvalidUserNameTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.enterInvalidUserName();

	}

	//@Test
	public void enterInvalidPasswordTest() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		loginpage.enterInvalidPassword();

	}
	@Test
	public void emptyUserName() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		loginpage.emptyUserName();

	}
	@Test
	public void emptyPassword() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		loginpage.emptyPassword();

	}

	@Test
	public void emptyCredentials() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		loginpage.emptyCredentials();

	}

	@Test
	public void navigateToAccountSummaryPageTest() {
		loginpage = homepage.clickSigninButton();
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.assertAccountSummaryPageTitle();

	}
	

}
