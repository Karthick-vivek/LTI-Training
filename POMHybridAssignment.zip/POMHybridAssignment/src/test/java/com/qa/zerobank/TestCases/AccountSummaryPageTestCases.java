package com.qa.zerobank.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LoginPage;

public class AccountSummaryPageTestCases extends TestBase {

	HomePage homepage;
	LoginPage loginpage;
	AccountSummaryPage accountsummarypage;

	public AccountSummaryPageTestCases() {

		super();
	}

	@BeforeMethod
	public void setup() {

		initialization();
		homepage = new HomePage();
		loginpage = new LoginPage();
		accountsummarypage = new AccountSummaryPage();

	}


	@AfterMethod
	public void quit() {
		driver.close();
		driver.quit();

	}
	@Test
	public void validateAccountSummaryPageTitle() {
		loginpage = homepage.clickSigninButton();
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.assertAccountSummaryPageTitle();
		accountsummarypage.signOut();
		System.out.println("Verified title");

	}


	@Test
	public void signOutTest() {
		loginpage = homepage.clickSigninButton();
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.signOut();
	}
}
